#!/bin/sh
cd "$1"
tar xvpf "$1/properties/version/nsf/backup/backupnsf.tar"
