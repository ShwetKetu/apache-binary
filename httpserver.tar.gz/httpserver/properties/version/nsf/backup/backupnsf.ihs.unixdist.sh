#!/bin/sh
cd "$1"
mkdir -m 755 properties/version/nsf
mkdir -m 755 properties/version/nsf/backup
tar cpf "$1/properties/version/nsf/backup/backupnsf.tar" bin/adminctl bin/apachectl bin/apr-1-config bin/apu-1-config bin/apxs bin/dbmmanage bin/envvars-std bin/genHistoryReport.bat bin/genHistoryReport.sh bin/genVersionReport.bat
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" bin/genVersionReport.sh bin/historyInfo.bat
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" bin/historyInfo.sh bin/managesdk.bat bin/managesdk.sh bin/setupCmdLine.bat bin/setupCmdLine.sh bin/setupadm bin/versionInfo.bat bin/versionInfo.sh build/apr_rules.mk
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" build/config_vars.mk build/instdso.sh build/libtool build/mkdir.sh build/shlibtool
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" lib/libapr-1.la lib/libaprutil-1.la lib/libexpat.la
#tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" java/jre/lib/security/java.policy
#tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" java/jre/lib/security/java.security
#tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" java/jre/lib/security/cacerts
#tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" java/jre/lib/orb.properties
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" conf/admin.passwd
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" htdocs/images/ihs/support.gif htdocs/images/ihs/help.gif htdocs/images/ihs/favicon.ico htdocs/images/ihs/foreground.gif htdocs/images/ihs/odot.gif htdocs/images/ihs/background.gif htdocs/images/ihs/notes.gif
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" htdocs/images/ihs/administration.gif htdocs/index_ihs.html htdocs/http_server_styles.css
tar rpf "$1/properties/version/nsf/backup/backupnsf.tar" properties/sdk/cmdDefaultSDK.properties properties/sdk/newProfileDefaultSDK.properties properties/postinstall/cacheRegistry.xml
